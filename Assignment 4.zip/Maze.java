import java.util.Random; // Needed for random numbers to create random walls and exits

public class Maze {
    // The grid is a 2D array of Tiles
    private Tile[][] grid;
    private int size;

    // Constructor to build the maze
    public Maze(int size) {
        this.size = size;
        grid = new Tile[size][size];
        createMaze(); // Calls method to fill the grid
    }

    // Method to fill the grid with walls and the exit
    private void createMaze() {
        Random rand = new Random();
        
        // First, fill the grid with tiles
        for (int x = 0; x < size; x++) {
            for (int y = 0; y < size; y++) {
                // Determine if this tile should be a wall. Let's say there is a 20% chance for a wall
                boolean isAWall = rand.nextDouble() < 0.2;

                //  Position (0,0) cannot be a wall.
                if (x == 0 && y == 0) {
                    isAWall = false;
                }

                // Create the tile (initially no exit)
                grid[x][y] = new Tile(isAWall, false);
            }
        }

        // Now place the exit randomly
        int exitX = rand.nextInt(size);
        int exitY = rand.nextInt(size);

        //  Exit cannot be at (0,0)
        // If it picked (0,0), pick a new spot until it's not (0,0)
        while (exitX == 0 && exitY == 0) {
            exitX = rand.nextInt(size);
            exitY = rand.nextInt(size);
        }

        /* Exit usually shouldn't be inside a wall,  but to keep it simple we just overwrite the tile at that spot
        with an Exit tile that isn't a wall.*/
        grid[exitX][exitY] = new Tile(false, true);
    }

    // Method to get a specific tile
    public Tile getTile(int x, int y) {
        // Check bounds just in case, though Main should handle valid moves
        if (x >= 0 && x < size && y >= 0 && y < size) {
            return grid[x][y];
        }
        return null;
    }

    // Getter for size
    public int getSize() {
        return size;
    }
}