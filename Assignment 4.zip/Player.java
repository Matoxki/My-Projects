
public class Player {
	// Attributes for position and energy
    private int x;
    private int y;
    private int energy;

    // Constructor to initialize the player
    public Player(int defaultEnergy) {
        // Player starts at bottom-left (0,0) which is the default position
        this.x = 0;
        this.y = 0;
        this.energy = defaultEnergy;
    }

    // Methods to move the player one step in a direction
    public void Up() {
        y = y + 1; // Increasing y goes up
    }

    public void Down() {
        y = y - 1; // Decreasing y goes down
    }

    public void Right() {
        x = x + 1; // Increasing x goes right
    }

    public void Left() {
        x = x - 1; // Decreasing x goes left
    }

    // Method to lower energy by 1
    public void decreaseEnergy() {
        energy = energy - 1;
    }

    // Getters to let other classes see the values
    public int getX() {
        return x;
    }

    public int getY() {
        return y;
    }

    public int getEnergy() {
        return energy;
    }

}
