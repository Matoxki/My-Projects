
public class Tile {
	// These variables hold the state of the tile
    // I am using private variables for encapsulation
    private boolean isAWall;
    private boolean isAnExit;

    // Constructor to set up the tile
    public Tile(boolean isAWall, boolean isAnExit) {
        this.isAWall = isAWall;
        this.isAnExit = isAnExit;
    }

    // Method to check if this tile is a wall
    public boolean isAWall() {
        return isAWall;
    }

    // Method to check if this tile is the exit
    public boolean isExit() {
        return isAnExit;
    }

}
