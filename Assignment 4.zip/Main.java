import java.util.Scanner; // to take user input W, A, S, D

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Configuration
        int mazeSize = 8; // Size is configurable 8x8
        int startEnergy = 20; // Give enough energy to have a chance

        // Create the objects
        Maze maze = new Maze(mazeSize);
        Player player = new Player(startEnergy);

        System.out.println("Maze Game!");
        System.out.println("Find the exit before your energy is exhusted.");
        System.out.println("Controls: W (Up), S (Down), A (Left), D (Right)");

        boolean gameIsRunning = true; // to set instructions based on the status of the player health and direction

        // Start the game loop
        while (gameIsRunning) {
            // 1. Print current status
            System.out.println("Player position: (" + player.getX() + ", " + player.getY() + ")");
            System.out.println("Energy: " + player.getEnergy());
            System.out.print("Move (W/A/S/D/Q to quit): ");

            // 2. Read input
            String input = scanner.next();
            // Convert to UPPERCASE to make it easier to check
            char move = input.toUpperCase().charAt(0);

            // Variables to calculate where the player WANTS to go
            int nextX = player.getX();
            int nextY = player.getY();

            // 3. Determine target position based on key
            if (move == 'W') {
                nextY = nextY + 1; // Up
            } else if (move == 'S') {
                nextY = nextY - 1; // Down
            } else if (move == 'D') {
                nextX = nextX + 1; // Right
            } else if (move == 'A') {
                nextX = nextX - 1; // Left
            } else if (move == 'Q') {
                System.out.println("You gave up!");
                break; // Exit the loop
            } else {
                System.out.println("Invalid input. PPlease use only W, A, S, D.");
                continue; // Skip the rest and ask again
            }

            // 4. Check if the move is valid. Check boundaries first (Player cannot leave grid)
            if (nextX < 0 || nextX >= maze.getSize() || nextY < 0 || nextY >= maze.getSize()) {
                System.out.println("You hit the edge of the world!");
                // Do not move, do not lose energy
            } else {
                // Check if it is a wall
                Tile targetTile = maze.getTile(nextX, nextY);
                
                if (targetTile.isAWall()) {
                    System.out.println("You hit a wall!");
                    // Do not move, do not lose energy (rule: because energy decreases only on success)
              } else {
                    // Move is successful!
                    
                    // Update player position
                    if (move == 'W') player.Up();
                    if (move == 'S') player.Down();
                    if (move == 'D') player.Right();
                    if (move == 'A') player.Left();

                    // Decrease energy
                    player.decreaseEnergy();

                    // Check for Win
                    if (targetTile.isExit()) {
                        System.out.println("Player position: (" + player.getX() + ", " + player.getY() + ")");
                        System.out.println("Energy: " + player.getEnergy());
                        System.out.println("You escaped the maze! Hurray!!");
                        gameIsRunning = false; // Stop the game
                   }
                    
                    // Check for Loss (Energy runs out)
                    else if (player.getEnergy() <= 0) {
                        System.out.println("Player position: (" + player.getX() + ", " + player.getY() + ")");
                        System.out.println("Energy: " + player.getEnergy());
                        System.out.println("Energy Exhausted! Game Over.");
                        gameIsRunning = false; // Stop the game
                    }
                }
            }
            
        }

        scanner.close();
    }
}
