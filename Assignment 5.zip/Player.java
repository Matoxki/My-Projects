public class Player extends Entity {
    
    private int loot; // how much treasure we have so far
    
    public Player(int x, int y) {
        super(x, y); // pass to entity
        loot = 0;
    }
    
    @Override
    public void move(char dir, Map m) {
        int nextX = pX;
        int nextY = pY;
        
        // Set move direction
        if(dir == 'W') {
            nextY = pY + 1;
        } else if(dir == 'S') {
            nextY = pY - 1;
        } else if(dir == 'A') {
            nextX = pX - 1;
        } else if(dir == 'D') {
            nextX = pX + 1;
        }
        
        // check if we can actually move there
        boolean canMove = m.isValidMove(nextX, nextY);
        
        if (canMove) {
            pX = nextX;
            pY = nextY;
            
            // Found treasure
            if (m.hasTreasure(pX, pY)) {
                m.removeTreasure(pX, pY);
                loot = loot + 1;
                System.out.println("Nice, found a treasure!");
            }
            
        } else {
            // When no movement. let's find out why
            if (!m.isWithinBoundary(nextX, nextY)) {
                System.out.println("cant leave the map area");
            } else if (m.isWall(nextX, nextY)) {
                System.out.println("you hit a wall...");
            }
        }
    }
    
    public int getTreasuresCollected() {
        return loot;
    }
}