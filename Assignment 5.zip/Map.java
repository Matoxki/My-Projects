import java.util.Random;

public class Map {
    
    boolean[][] wallArray;
    boolean[][] lootArray;
    int s; // size of the map
    int totalLoot;
    
    public Map(int size) {
        s = size;
        wallArray = new boolean[s][s];
        lootArray = new boolean[s][s];
        totalLoot = 0;
        
        Random rand = new Random();
        
        // setup the walls first
        for(int i=0; i<s; i++) {
            for(int j=0; j<s; j++) {
                
                // leave starting position alone
                if(i==0 && j==0) continue;
                
                // about 1 in 5 chance for a wall
                if(rand.nextInt(5) == 0) {
                    wallArray[i][j] = true;
                }
            }
        }
        
        // now drop the treasures
        for(int i=0; i<s; i++) {
            for(int j=0; j<s; j++) {
                
                // skip if it's the start or there's a wall here
                if((i==0 && j==0) || wallArray[i][j]) {
                    continue;
                }
                
                if(rand.nextInt(7) == 0) {
                    lootArray[i][j] = true;
                    totalLoot++;
                }
            }
        }
        
        // just in case rng generated 0 treasures
        if(totalLoot == 0) {
            int rx = rand.nextInt(s);
            int ry = rand.nextInt(s);
            
            // keep rerolling until we find an empty spot
            while((rx==0 && ry==0) || wallArray[rx][ry]) {
                rx = rand.nextInt(s);
                ry = rand.nextInt(s);
            }
            lootArray[rx][ry] = true;
            totalLoot = 1;
        }
    }
    
    public boolean isWithinBoundary(int x, int y) {
        return (x >= 0 && x < s && y >= 0 && y < s);
    }
    
    public boolean isWall(int x, int y) {
        if(!isWithinBoundary(x, y)) return false;
        return wallArray[x][y];
    }
    
    public boolean hasTreasure(int x, int y) {
        if(!isWithinBoundary(x, y)) return false;
        return lootArray[x][y];
    }
    
    public void removeTreasure(int x, int y) {
        if(isWithinBoundary(x, y)) {
            lootArray[x][y] = false;
        }
    }
    
    public boolean isValidMove(int x, int y) {
        if(isWithinBoundary(x, y) && !wallArray[x][y]) {
            return true;
        }
        return false;
    }
    
    public int getTotalTreasures() {
        return totalLoot;
    }
    
    public int getSize() {
        return s;
    }
    
    public int[] getRandomPosition() {
        Random r = new Random();
        int rx, ry;
        
        // brute force a random location that isn't a wall or spawn
        while(true) {
            rx = r.nextInt(s);
            ry = r.nextInt(s);
            
            if(!(rx == 0 && ry == 0) && !wallArray[rx][ry]) {
                break;
            }
        }
        
        return new int[]{rx, ry};
    }
}