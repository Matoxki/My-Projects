public abstract class Entity {
    // keeping track of where the thing is
    protected int pX;
    protected int pY;
    
    public Entity(int startX, int startY) {
        this.pX = startX;
        this.pY = startY;
    }
    
    //Have to override this in the child classes
    public abstract void move(char dir, Map m);
    
    public int getX() {
        return pX;
    }
    
    public int getY() {
        return pY;
    }
    
    public void setX(int x) {
        this.pX = x;
    }
    
    public void setY(int y) {
        this.pY = y;
    }
}