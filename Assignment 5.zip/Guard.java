import java.util.Random;

public class Guard extends Entity {
    
    Random rng = new Random();
    
    public Guard(int startX, int startY) {
        super(startX, startY);
    }
    
    @Override
    public void move(char dir, Map m) {
        // guard moves randomly. let's try 10 times to find a valid spot
        for(int i = 0; i < 10; i++) {
            int roll = rng.nextInt(4); // 0, 1, 2, or 3
            
            int tempX = pX;
            int tempY = pY;
            
            if(roll == 0) tempY++; // W
            if(roll == 1) tempY--; // S
            if(roll == 2) tempX--; // A
            if(roll == 3) tempX++; // D
            
            // if it's a good spot, move and exit the loop
            if (m.isValidMove(tempX, tempY)) {
                pX = tempX;
                pY = tempY;
                break; // moved succesful, exit
            }
        }
    }
}