import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        
        int bSize = 10;
        Map mapObj = new Map(bSize);
        
        Player p1 = new Player(0, 0);
        
        // spawn guard somewhere random
        int[] loc = mapObj.getRandomPosition();
        Guard g1 = new Guard(loc[0], loc[1]);
        
        ArrayList<Entity> allMobiles = new ArrayList<>();
        allMobiles.add(p1);
        allMobiles.add(g1);
        
        boolean running = true;
        
        System.out.println("game starting...");
        System.out.println("try to collect all " + mapObj.getTotalTreasures() + " treasures.");
        System.out.println("dont let the guard touch you.");
        System.out.println();
        
        while(running) {
            System.out.println("Player: (" + p1.getX() + ", " + p1.getY() + ")");
            System.out.println("Guard: (" + g1.getX() + ", " + g1.getY() + ")");
            System.out.println("Loot: " + p1.getTreasuresCollected() + " / " + mapObj.getTotalTreasures());
            System.out.print("Move (W/A/S/D): ");
            
            String in = sc.nextLine().toUpperCase().trim();
            
            // if they just press enter by accident
            if(in.length() == 0) {
                System.out.println("pls enter a direction.");
                System.out.println();
                continue;
            }
            
            char d = in.charAt(0);
            
            if(d != 'W' && d != 'A' && d != 'S' && d != 'D') {
                System.out.println("bad input. use W, A, S, or D.");
                System.out.println();
                continue;
            }
            
            // update player
            p1.move(d, mapObj);
            
            // win check
            if(p1.getTreasuresCollected() >= mapObj.getTotalTreasures()) {
                System.out.println("\n--- YOU WIN ---");
                System.out.println("got all the loot!");
                running = false;
                break;
            }
            
            // update guard
            g1.move(d, mapObj);
            
            // lose check (did the guard step on us?)
            if(p1.getX() == g1.getX() && p1.getY() == g1.getY()) {
                System.out.println("\n--- GAME OVER ---");
                System.out.println("the guard caught you. RIP.");
                running = false;
                break;
            }
            
            System.out.println(); // space it out for the next turn
        }
        
        sc.close();
    }
}